<!DOCTYPE html>
<html class="light" lang="pt-br">
<head>
  <meta charset="utf-8"/>
  <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
  <title>Peludos Unipê - Adote Amor</title>

    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>

    <link href="https://fonts.googleapis.com" rel="preconnect"/>
  <link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&amp;display=swap" rel="stylesheet"/>
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet"/>

    <script>
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#FF7D63",
                        "background-light": "#FFF8F0",
                        "background-dark": "#0B4F6C",
                        "text-light": "#0B4F6C",
                        "text-dark": "#FFF8F0",
                        "accent": "#A8DADC"
                    },
                    fontFamily: {
                        "display": ["Plus Jakarta Sans", "sans-serif"]
                    },
                    borderRadius: {
                        "DEFAULT": "0.5rem",
                        "lg": "1rem",
                        "xl": "1.5rem",
                        "full": "9999px"
                    },
                },
            },
        }
  </script>

    <link rel="stylesheet" href="styles.css">
</head>

<body class="bg-background-light dark:bg-background-dark font-display text-text-light dark:text-text-dark">

  <div class="relative flex h-auto min-h-screen w-full flex-col group/design-root overflow-x-hidden" id="home">
    <div class="layout-container flex h-full grow flex-col">
      <header class="sticky top-0 z-50 flex items-center justify-between whitespace-nowrap border-b border-solid border-primary/20 px-4 sm:px-10 py-3 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-sm">
        <div class="flex items-center gap-4">
          <div class="size-6 text-primary">
            <svg fill="none" viewbox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
              <path d="M36.7273 44C33.9891 44 31.6043 39.8386 30.3636 33.69C29.123 39.8386 26.7382 44 24 44C21.2618 44 18.877 39.8386 17.6364 33.69C16.3957 39.8386 14.0109 44 11.2727 44C7.25611 44 4 35.0457 4 24C4 12.9543 7.25611 4 11.2727 4C14.0109 4 16.3957 8.16144 17.6364 14.31C18.877 8.16144 21.2618 4 24 4C26.7382 4 29.123 8.16144 30.3636 14.31C31.6043 8.16144 33.9891 4 36.7273 4C40.7439 4 44 12.9543 44 24C44 35.0457 40.7439 44 36.7273 44Z" fill="currentColor"></path>
            </svg>
          </div>
          <h2 class="text-text-light dark:text-text-dark text-lg font-bold leading-tight tracking-[-0.015em]">Peludos Unipê</h2>
        </div>

        <div class="hidden md:flex flex-1 justify-end gap-8">
          <div class="flex items-center gap-9">
            <a class="text-text-light dark:text-text-dark text-sm font-medium leading-normal" href="#home">Home</a>
            <a class="text-text-light dark:text-text-dark text-sm font-medium leading-normal" href="#sobre">Sobre</a>
            <a class="text-text-light dark:text-text-dark text-sm font-medium leading-normal" href="#adocao">Adoção</a>
            <a class="text-text-light dark:text-text-dark text-sm font-medium leading-normal" href="#contato">Contato</a>
          </div>
          <button class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-primary text-white text-sm font-bold leading-normal tracking-[0.015em]">
            <span class="truncate">Quero Adotar!</span>
          </button>
        </div>
      </header>

      <main class="flex-1">
        <section class="w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
          <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div class="flex flex-col gap-6 text-center lg:text-left">
              <h1 class="text-4xl font-black leading-tight tracking-[-0.033em] sm:text-5xl lg:text-6xl text-text-light dark:text-text-dark">Adote um Peludo 😻</h1>
              <h2 class="text-base font-normal leading-normal sm:text-lg text-text-light/80 dark:text-text-dark/80">Mude uma vida para sempre. Encontre seu novo melhor amigo e dê a ele o lar que ele merece.</h2>
              <a class="flex self-center lg:self-start min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-12 px-5 bg-primary text-white text-base font-bold leading-normal tracking-[0.015em]" href="#adocao">
                <span class="truncate">Quero Adotar!</span>
              </a>
            </div>
            <div class="w-full bg-center bg-no-repeat aspect-square bg-cover" style='background-image: url("../assets/img/gato5.png");'></div>
          </div>
        </section>

        <section class="w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
          <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div class="flex flex-col gap-4 items-center text-center p-6 bg-background-light dark:bg-text-light/10 rounded-xl border border-primary/20">
              <span class="material-symbols-outlined text-4xl text-primary">volunteer_activism</span>
              <h3 class="text-lg font-bold text-text-light dark:text-text-dark">Faça uma Doação</h3>
              <p class="text-sm font-normal leading-normal text-text-light/80 dark:text-text-dark/80">Sua contribuição ajuda a cobrir custos de veterinário, comida e cuidados para nossos animais.</p>
              <button class="mt-2 w-full flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-accent text-text-light text-sm font-bold leading-normal tracking-[0.015em]">
                <span class="truncate">Doar Agora</span>
              </button>
            </div>

            <div class="flex flex-col gap-4 items-center text-center p-6 bg-background-light dark:bg-text-light/10 rounded-xl border border-primary/20">
              <span class="material-symbols-outlined text-4xl text-primary">pets</span>
              <h3 class="text-lg font-bold text-text-light dark:text-text-dark">Seja um Padrinho/Madrinha</h3>
              <p class="text-sm font-normal leading-normal text-text-light/80 dark:text-text-dark/80">Apoie um peludo específico mensalmente e receba atualizações sobre o bem-estar dele.</p>
              <button class="mt-2 w-full flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-accent text-text-light text-sm font-bold leading-normal tracking-[0.015em]">
                <span class="truncate">Apadrinhar</span>
              </button>
            </div>

            <div class="flex flex-col gap-4 items-center text-center p-6 bg-background-light dark:bg-text-light/10 rounded-xl border border-primary/20">
              <span class="material-symbols-outlined text-4xl text-primary">favorite</span>
              <h3 class="text-lg font-bold text-text-light dark:text-text-dark">Quero Adotar!</h3>
              <p class="text-sm font-normal leading-normal text-text-light/80 dark:text-text-dark/80">Veja os perfis dos nossos gatos que estão esperando por um lar amoroso.</p>
              <a class="mt-2 w-full flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-primary text-white text-sm font-bold leading-normal tracking-[0.015em]" href="#adocao">
                <span class="truncate">Ver Peludos</span>
              </a>
            </div>
          </div>
        </section>

        <section class="w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24" id="sobre">
          <div class="text-center mb-12">
            <h2 class="text-3xl font-bold tracking-tight sm:text-4xl text-text-light dark:text-text-dark">Nossa Missão</h2>
            <p class="mt-4 max-w-3xl mx-auto text-lg text-text-light/80 dark:text-text-dark/80">Nossa principal missão é atuar como um elo entre animais (cães e gatos) que necessitam de ajuda e lares amorosos e responsáveis. Somos uma iniciativa de trabalho voluntário, e não uma ONG formal, que mobiliza a comunidade em prol da causa animal na Paraíba, com forte atuação no Centro Universitário de João Pessoa (Unipê).</p>
          </div>
          <div class="mt-16">
            <h3 class="text-2xl font-bold text-center mb-10 text-text-light dark:text-text-dark">Como Funciona a Adoção?</h3>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div class="flex flex-col items-center">
                <div class="flex items-center justify-center w-16 h-16 rounded-full bg-accent text-text-light mb-4 text-2xl font-bold">1</div>
                <h4 class="font-semibold text-lg text-text-light dark:text-text-dark">Escolha seu Pet</h4>
                <p class="text-sm text-text-light/80 dark:text-text-dark/80">Navegue pelos perfis dos nossos peludos e se apaixone.</p>
              </div>
              <div class="flex flex-col items-center">
                <div class="flex items-center justify-center w-16 h-16 rounded-full bg-accent text-text-light mb-4 text-2xl font-bold">2</div>
                <h4 class="font-semibold text-lg text-text-light dark:text-text-dark">Preencha o Formulário</h4>
                <p class="text-sm text-text-light/80 dark:text-text-dark/80">Conte-nos um pouco sobre você e o lar que pode oferecer.</p>
              </div>
              <div class="flex flex-col items-center">
                <div class="flex items-center justify-center w-16 h-16 rounded-full bg-accent text-text-light mb-4 text-2xl font-bold">3</div>
                <h4 class="font-semibold text-lg text-text-light dark:text-text-dark">Leve para Casa</h4>
                <p class="text-sm text-text-light/80 dark:text-text-dark/80">Após aprovação, prepare-se para receber seu novo melhor amigo!</p>
              </div>
            </div>
          </div>
        </section>

        <section class="w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24" id="adocao">
          <div class="text-center mb-12">
            <h2 class="text-3xl font-bold tracking-tight sm:text-4xl text-text-light dark:text-text-dark">Nossos Peludos Esperando um Lar</h2>
          </div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 *gap-12*">
                        <div class="flex flex-col bg-background-light dark:bg-text-light/10 rounded-xl overflow-hidden border border-primary/20">
            <div class="w-full bg-center bg-no-repeat aspect-square bg-cover" style='background-image: url("../assets/img/gato1.png");'></div>
              <div class="p-4 flex flex-col flex-1">
                <h3 class="text-xl font-bold text-text-light dark:text-text-dark">Kiara</h3>
                <p class="text-sm text-text-light/80 dark:text-text-dark/80">Fêmea, 5 Meses</p>
                <button class="mt-4 w-full flex items-center justify-center rounded-lg h-10 px-4 bg-primary text-white text-sm font-bold">Ver Perfil</button>
              </div>
            </div>

                        <div class="flex flex-col bg-background-light dark:bg-text-light/10 rounded-xl overflow-hidden border border-primary/20">
            <div class="w-full bg-center bg-no-repeat aspect-square bg-cover" style='background-image: url("../assets/img/gato2.png");'></div>
              <div class="p-4 flex flex-col flex-1">
                <h3 class="text-xl font-bold text-text-light dark:text-text-dark">Nala</h3>
                <p class="text-sm text-text-light/80 dark:text-text-dark/80">Fêmea, 5 Meses</p>
                <button class="mt-4 w-full flex items-center justify-center rounded-lg h-10 px-4 bg-primary text-white text-sm font-bold">Ver Perfil</button>
              </div>
            </div>

                        <div class="flex flex-col bg-background-light dark:bg-text-light/10 rounded-xl overflow-hidden border border-primary/20">
            <div class="w-full bg-center bg-no-repeat aspect-square bg-cover" style='background-image: url("../assets/img/gato3.png");'></div>
              <div class="p-4 flex flex-col flex-1">
                <h3 class="text-xl font-bold text-text-light dark:text-text-dark">Tom</h3>
                <p class="text-sm text-text-light/80 dark:text-text-dark/80">Macho, 3 anos</p>
                <button class="mt-4 w-full flex items-center justify-center rounded-lg h-10 px-4 bg-primary text-white text-sm font-bold">Ver Perfil</button>
              </div>
            </div>

                        <div class="flex flex-col bg-background-light dark:bg-text-light/10 rounded-xl overflow-hidden border border-primary/20">
            <div class="w-full bg-center bg-no-repeat aspect-square bg-cover" style='background-image: url("../assets/img/gato4.png");'></div>
              <div class="p-4 flex flex-col flex-1">
                <h3 class="text-xl font-bold text-text-light dark:text-text-dark">Olive</h3>
                <p class="text-sm text-text-light/80 dark:text-text-dark/80">Macho, 3 anos</p>
                <button class="mt-4 w-full flex items-center justify-center rounded-lg h-10 px-4 bg-primary text-white text-sm font-bold">Ver Perfil</button>
              </div>
            </div>

                        <div class="flex flex-col bg-background-light dark:bg-text-light/10 rounded-xl overflow-hidden border border-primary/20">
            <div class="w-full bg-center bg-no-repeat aspect-square bg-cover" style='background-image: url("../assets/img/gato5.png");'></div>
              <div class="p-4 flex flex-col flex-1">
                <h3 class="text-xl font-bold text-text-light dark:text-text-dark">Amora</h3>
                <p class="text-sm text-text-light/80 dark:text-text-dark/80">Fêmea, 2 a 3 anos</p>
                <button class="mt-4 w-full flex items-center justify-center rounded-lg h-10 px-4 bg-primary text-white text-sm font-bold">Ver Perfil</button>
              </div>
            </div>
          </div>
        </section>

        <section class="w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24" id="contato">
          <div class="max-w-xl mx-auto text-center">
            <h2 class="text-3xl font-bold tracking-tight sm:text-4xl text-text-light dark:text-text-dark">Fale Conosco</h2>
            <p class="mt-4 text-lg text-text-light/80 dark:text-text-dark/80">Tem alguma dúvida ou quer saber mais sobre nosso trabalho? Mande uma mensagem</p>
          </div>

          <form class="mt-12 max-w-xl mx-auto">
            <div class="grid grid-cols-1 gap-y-6">
              <div>
                <label class="sr-only" for="name">Nome</label>
                <input autocomplete="name" class="block w-full rounded-lg border-primary/30 shadow-sm py-3 px-4 placeholder:text-text-light/50 focus:border-primary focus:ring-primary bg-background-light dark:bg-text-light/10 dark:text-text-dark" id="name" name="name" placeholder="Nome" type="text"/>
              </div>
              <div>
                <label class="sr-only" for="email">Email</label>
                <input autocomplete="email" class="block w-full rounded-lg border-primary/30 shadow-sm py-3 px-4 placeholder:text-text-light/50 focus:border-primary focus:ring-primary bg-background-light dark:bg-text-light/10 dark:text-text-dark" id="email" name="email" placeholder="Email" type="email"/>
              </div>
              <div>
                <label class="sr-only" for="subject">Assunto</label>
                <input class="block w-full rounded-lg border-primary/30 shadow-sm py-3 px-4 placeholder:text-text-light/50 focus:border-primary focus:ring-primary bg-background-light dark:bg-text-light/10 dark:text-text-dark" id="subject" name="subject" placeholder="Assunto" type="text"/>
              </div>
              <div>
                <label class="sr-only" for="message">Mensagem</label>
                <textarea class="block w-full rounded-lg border-primary/30 shadow-sm py-3 px-4 placeholder:text-text-light/50 focus:border-primary focus:ring-primary bg-background-light dark:bg-text-light/10 dark:text-text-dark" id="message" name="message" placeholder="Mensagem" rows="4"></textarea>
              </div>
              <div>
                <button class="w-full flex items-center justify-center px-6 py-3 border border-transparent rounded-xl shadow-sm text-base font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary" type="submit">Enviar Mensagem</button>
              </div>
            </div>
          </form>
        </section>

      </main>

      <footer class="bg-text-light text-background-light dark:bg-black/20 dark:text-text-dark">
        <div class="w-full max-w-6xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div class="xl:grid xl:grid-cols-3 xl:gap-8">
            <div class="space-y-8 xl:col-span-1">
              <div class="flex items-center gap-4">
                <div class="size-6 text-primary">
                  <svg fill="none" viewbox="0 0 48 48" xmlns="http://www.w3.org/2000/svg"><path d="M36.7273 44C33.9891 44 31.6043 39.8386 30.3636 33.69C29.123 39.8386 26.7382 44 24 44C21.2618 44 18.877 39.8386 17.6364 33.69C16.3957 39.8386 14.0109 44 11.2727 44C7.25611 44 4 35.0457 4 24C4 12.9543 7.25611 4 11.2727 4C14.0109 4 16.3957 8.16144 17.6364 14.31C18.877 8.16144 21.2618 4 24 4C26.7382 4 29.123 8.16144 30.3636 14.31C31.6043 8.16144 33.9891 4 36.7273 4C40.7439 4 44 12.9543 44 24C44 35.0457 40.7439 44 36.7273 44Z" fill="currentColor"></path></svg>
                </div>
                <h2 class="text-lg font-bold">Peludos Unipê</h2>
              </div>
              <p class="text-sm">Salvando vidas, uma patinha de cada vez.</p>
            </div>
            <div class="mt-12 grid grid-cols-2 gap-8 xl:mt-0 xl:col-span-2">
              <div class="md:grid md:grid-cols-2 md:gap-8">
                <div>
                  <h3 class="text-sm font-semibold tracking-wider uppercase">Navegação</h3>
                  <ul class="mt-4 space-y-4" role="list">
                    <li><a class="text-base hover:text-primary" href="#home">Home</a></li>
                    <li><a class="text-base hover:text-primary" href="#sobre">Sobre</a></li>
                    <li><a class="text-base hover:text-primary" href="#adocao">Adoção</a></li>
                    <li><a class="text-base hover:text-primary" href="#contato">Contato</a></li>
                  </ul>
                </div>
                <div class="mt-12 md:mt-0">
                  <h3 class="text-sm font-semibold tracking-wider uppercase">Ajude</h3>
                  <ul class="mt-4 space-y-4" role="list">
                    <li><a class="text-base hover:text-primary" href="#">Doar</a></li>
                    <li><a class="text-base hover:text-primary" href="#">Apadrinhar</a></li>
                    <li><a class="text-base hover:text-primary" href="#">Ser Voluntário</a></li>
                  </ul>
                </div>
              </div>
              <div class="md:grid md:grid-cols-1 md:gap-8">
                <div>
                  <h3 class="text-sm font-semibold tracking-wider uppercase">Siga-nos</h3>
                  <div class="flex mt-4 space-x-6">
                  <a class="hover:text-primary" href="https://www.instagram.com/peludosunipe/" target="_blank">
    <span class="sr-only">Instagram</span>
    <svg aria-hidden="true" class="h-6 w-6" fill="currentColor" viewbox="0 0 24 24">
        <path clip-rule="evenodd" d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.024.06 1.378.06 3.808s-.012 2.784-.06 3.808c-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.024.048-1.378.06-3.808.06s-2.784-.012-3.808-.06c-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.048-1.024-.06-1.378-.06-3.808s.012-2.784.06-3.808c.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 016.345 2.525c.636-.247 1.363-.416 2.427-.465C9.792 2.013 10.146 2 12.315 2zm-1.161 1.043c-2.43 0-2.757.01-3.725.058-.94.043-1.512.2-1.99.377a3.9 3.9 0 00-1.416 1.052c-.454.454-.755.9-1.052 1.416-.177.478-.335 1.05-.377 1.99-.048.968-.058 1.295-.058 3.725s.01 2.757.058 3.725c.043.94.2 1.512.377 1.99a3.9 3.9 0 001.052 1.416c.454.454.9.755 1.416 1.052.478.177 1.05.335 1.99.377.968.048 1.295.058 3.725.058s2.757-.01 3.725-.058c.94-.043 1.512-.2 1.99-.377a3.9 3.9 0 001.416-1.052c.454-.454.755-.9 1.052-1.416.177-.478.335-1.05.377-1.99.048-.968.058-1.295.058-3.725s-.01-2.757-.058-3.725c-.043-.94-.2-1.512-.377-1.99a3.9 3.9 0 00-1.052-1.416 3.9 3.9 0 00-1.416-1.052c-.478-.177-1.05-.335-1.99-.377-.968-.048-1.295-.058-3.725-.058zm0 2.446c.94 0 1.77.29 2.413.78a4.01 4.01 0 011.66 2.413c.18.73.27 1.55.27 2.413s-.09 1.683-.27 2.413a4.01 4.01 0 01-1.66 2.413c-.643.49-1.473.78-2.413.78s-1.77-.29-2.413-.78a4.01 4.01 0 01-1.66-2.413c-.18-.73-.27-1.55-.27-2.413s.09-1.683.27-2.413a4.01 4.01 0 011.66-2.413c.643-.49 1.473-.78 2.413-.78z" fill-rule="evenodd"></path>
    </svg>
</a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="mt-12 border-t border-background-light/20 pt-8">
          <footer>
         <p>© 2025 Peludos Unipê 🐾 | Projeto desenvolvido por 
        <strong>Layssa Evellyn</strong> e <strong>Tainara David</strong> — 
        Centro Universitário de João Pessoa.
        </p>
        </footer>
  <script src="../assets/js/patinhas.js"></script>
            <p class="text-base text-center">Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>

    </div>
  </div>
</body>
</html>
